<?php
include '../../include/shi-config.php';
include '../../include/functions.php';

$method = isset($_REQUEST["method"]) ? $_REQUEST["method"] : "";
$type = isset($_REQUEST["type"]) ? $_REQUEST['type'] : "";
$tabID = isset($_REQUEST["tabID"]) ? $_REQUEST['tabID'] : "";
$role = $_REQUEST['role'] ?? ''; 

// Enable all error reporting
// error_reporting(E_ALL); 
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Display errors in the browser
// ini_set('display_errors', 1);

// Optional: Show startup errors as well
// ini_set('display_startup_errors', 1);

if ($type == 'agent') {
    $role = isset($_REQUEST["role"]) ? "`roll_id` IN ($role) AND" : "";
} else {
    $role = isset($_REQUEST["role"]) ? "`roll_id` = '$role' AND" : "";
}

$headers = apache_request_headers();
$result = [];

$post_csrf = $headers['X-Csrf-Token'] ?? '';


if ($method == "create_category") {

    try {

        $cat_name = trim($_POST['cat_name'] ?? '');
        $cat_url  = trim($_POST['cat_url'] ?? '');
        // $cat_schema = $_POST['cat_schema'] ?? '';
        // $schemaArray = json_decode($cat_schema, true);
        
        // var_dump($schemaArray);
        // die;
        
        // $checkQuery = "SELECT id FROM categories WHERE cat_url = '$cat_url'";
        // $checkResult = $con->query($checkQuery);

       if ($cat_name === '' || $cat_url === '') {
            echo json_encode([
                'type'   => 0,
                'result' => 'Invalid input'
            ]);
            exit;
        } else {
            
            $insertQuery = "
                INSERT INTO categories (cat_name, cat_url) 
                VALUES ('$cat_name', '$cat_url')
            ";

            if ($con->query($insertQuery)) {
                echo json_encode([
                    'type'   => 1,
                    'result' => 'Category created successfully'
                ]);
            } else {
                echo json_encode([
                    'type'   => 0,
                    'result' => 'Insert failed'
                ]);
            }
        }

    } catch (Exception $e) {

        echo json_encode([
            'type'   => 0,
            'result' => $e->getMessage()
        ]);
    }

    exit;
}
else if ($method === 'create_index') {

    $c_query = "
        SELECT 
            'create_cat' AS row_type,
            id,
            cat_name AS category_name,
            cat_url AS category_url,
            cat_schema,
            status
        FROM categories WHERE deleted_at = 0
    ";

    $result_data = mysqli_query($con, $c_query);

    $response = [
        "type"   => 0,
        "result" => []
    ];

    if ($result_data && mysqli_num_rows($result_data) > 0) {

        while ($row = mysqli_fetch_assoc($result_data)) {
            $response["result"][] = $row;
        }

        $response["type"] = 1;
    }

    echo json_encode($response);
    exit; 
}
else if ($method === 'update_category') {
    
     $category_name = trim($_POST['cat_name'] ?? '');
     $category_url = trim($_POST['cat_url'] ?? '');
     $category_id = $_POST['id'];
     
    //  var_dump($schemaArray);die;
     
      if ($category_name === '' || $category_url === '' || $category_id === 0) {
        echo json_encode([
            "type"   => 0,
            "result" => "Invalid input"
        ]);
        exit;
    }

    $c_query = "
        UPDATE categories SET  
            cat_name = '$category_name', cat_url = '$category_url'
        WHERE id = $category_id
    ";
    
    
    $result_data = mysqli_query($con, $c_query);

    $response = [
        "type"   => 0,
        "result" => []
    ];

    if ($result_data && mysqli_affected_rows($con) > 0) {
        $response["type"]   = 1;
        $response["result"] = "Category updated successfully";
    } else {
        $response["type"]   = 0;
        $response["result"] = "No changes made or update failed";
    }
    
    echo json_encode($response);
    exit;
}
else if ($method === 'delete_category') {
    
     $category_id = $_POST['id'];
     
      if ($category_name === '' || $category_url === '' || $category_id === 0) {
        echo json_encode([
            "type"   => 0,
            "result" => "Invalid input"
        ]);
        exit;
    }

    $c_query = "
        UPDATE categories SET  
            deleted_at = '1'
        WHERE id = $category_id
    ";
    
    
    $result_data = mysqli_query($con, $c_query);

    $response = [
        "type"   => 0,
        "result" => []
    ];

    if ($result_data && mysqli_affected_rows($con) > 0) {
        $response["type"]   = 1;
        $response["result"] = "Deleted successfully";
    } else {
        $response["type"]   = 0;
        $response["result"] = "Deleted failed";
    }
    
    echo json_encode($response);
    exit;
}
else if ($method === 'update-status') {
    
    $category_id = $_POST['id'];
    $status = $_POST['status'] == 1 ? 1 : 0;
     
      if ($category_name === '' || $category_url === '' || $category_id === 0) {
        echo json_encode([
            "type"   => 0,
            "result" => "Invalid input"
        ]);
        exit;
    }

    $c_query = "
        UPDATE categories SET  
           status = '$status'
        WHERE id = $category_id
    ";
    // var_dump($c_query);die;
    
    
    $result_data = mysqli_query($con, $c_query);

    $response = [
        "type"   => 0,
        "result" => []
    ];

    if ($result_data && mysqli_affected_rows($con) > 0) {
        $response["type"]   = 1;
        $response["result"] = "Deleted successfully";
    } else {
        $response["type"]   = 0;
        $response["result"] = "Deleted failed";
    }
    
    echo json_encode($response);
    exit;
}
resutGJHIP:
echo json_encode($result);