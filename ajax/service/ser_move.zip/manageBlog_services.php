<?php
include '../../include/shi-config.php';
include '../../include/functions.php';

$method = isset($_REQUEST["method"]) ? $_REQUEST["method"] : "";
$type = isset($_REQUEST["type"]) ? $_REQUEST['type'] : "";
$tabID = isset($_REQUEST["tabID"]) ? $_REQUEST['tabID'] : "";
$role = $_REQUEST['role'] ?? ''; 

// Enable all error reporting
// error_reporting(E_ALL); 
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Display errors in the browser
// ini_set('display_errors', 1);

// Optional: Show startup errors as well
// ini_set('display_startup_errors', 1);

if ($type == 'agent') {
    $role = isset($_REQUEST["role"]) ? "`roll_id` IN ($role) AND" : "";
} else {
    $role = isset($_REQUEST["role"]) ? "`roll_id` = '$role' AND" : "";
}

$headers = apache_request_headers();
$result = [];

$post_csrf = $headers['X-Csrf-Token'] ?? '';


if ($method === 'create_index') {

    $category_id = $_POST['category_id'] ?? '';

    // Base query
    $c_query = "
        SELECT 
            'content_cat' AS row_type,
            bl.id,
            bl.category_id,
            bl.blog_title,
            bl.slug,
            bl.published_date,
            bl.faq,
            bl.thumbnail,
            bl.hero_image,
            bl.status,
            ca.cat_name
        FROM blogs_content bl
        LEFT JOIN categories ca ON ca.id = bl.category_id
        WHERE bl.deleted_at = '0'
    ";

    // Filter by category if selected
    if (!empty($category_id)) {
        $category_id = mysqli_real_escape_string($con, $category_id);
        $c_query .= " AND bl.category_id = '$category_id'";
    }

    $result_data = mysqli_query($con, $c_query);

    $response = [
        "type"   => 0,
        "result" => []
    ];

    if ($result_data && mysqli_num_rows($result_data) > 0) {
        while ($row = mysqli_fetch_assoc($result_data)) {
            $response["result"][] = $row;
        }
        $response["type"] = 1;
    }

    echo json_encode($response);
    exit;
}

else if ($method === 'delete_category') {
    
     $blog_id = $_POST['id'];
    //  var_dump($blog_id);die;
     
      if ($blog_id === 0) {
        echo json_encode([
            "type"   => 0,
            "result" => "Invalid input"
        ]);
        exit;
    }

    $c_query = "
         UPDATE blogs_content SET deleted_at = '1'
        WHERE id = $blog_id
    ";
    
    
    $result_data = mysqli_query($con, $c_query);

    $response = [
        "type"   => 0,
        "result" => []
    ];

    if ($result_data && mysqli_affected_rows($con) > 0) {
        $response["type"]   = 1;
        $response["result"] = "Deleted successfully";
    } else {
        $response["type"]   = 0;
        $response["result"] = "Deleted failed";
    }
    
    echo json_encode($response);
    exit;
}

else if ($method === 'update_status') {
    
    $category_id = $_POST['id'];
    $status = $_POST['status'] == 1 ? 1 : 0;
    // var_dump($status);die;
     
      if ($category_id === 0) {
        echo json_encode([
            "type"   => 0,
            "result" => "Invalid input"
        ]);
        exit;
    }

    $c_query = "
        UPDATE blogs_content SET  
           status = '$status'
        WHERE id = $category_id
    ";
    // var_dump($c_query);die;
    
    
    $result_data = mysqli_query($con, $c_query);

    $response = [
        "type"   => 0,
        "result" => []
    ];

    if ($result_data && mysqli_affected_rows($con) > 0) {
        $response["type"]   = 1;
        $response["result"] = "Deleted successfully";
    } else {
        $response["type"]   = 0;
        $response["result"] = "Deleted failed";
    }
    
    echo json_encode($response);
    exit;
}

else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
  

    $action            = $_POST['action'] ?? '';
    $method            = $_POST['method'] ?? '';
    $category_id       = $_POST['category_id'] ?? '';
    $published_date    = $_POST['published_date'] ?? '';
    $sub_title         = $_POST['sub_title'] ?? '';
    $blog_title        = $_POST['blog_title'] ?? '';
    $slug              = $_POST['slug'] ?? '';
    $blog_id              = $_POST['blog_id'] ?? '';
    $read_minutes      = $_POST['read_minutes'] ?? '';
    $seo_title         = $_POST['seo_title'] ?? '';
    $meta_description  = $_POST['meta_description'] ?? '';
    $meta_keywords     = $_POST['meta_keywords'] ?? '';
    $content           = $_POST['content'] ?? '';
    $label_h        = $_POST['label_h'] ?? '';
    $content_p        = $_POST['content_p'] ?? '';
    $faq_answer        = $_POST['faq_answer'] ?? '';
    $faq_question       = $_POST['faq_question'] ?? '';
    // var_dump($faq_question);die;
    

    $getImg = $con->query("SELECT hero_image, thumbnail FROM blogs_content WHERE id = '$blog_id'");
    $rowImg = $getImg->fetch_assoc();
    
    $hero_image = $rowImg['hero_image'];
    $thumbnail  = $rowImg['thumbnail'];

    /* ================= HERO IMAGE UPLOAD ================= */

   // HERO IMAGE
    if (isset($_FILES['hero_image']) && $_FILES['hero_image']['error'] === UPLOAD_ERR_OK) {
    
        $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/blog/';
        $uploadPath = 'assets/images/blog/';
    
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
    
        $ext = pathinfo($_FILES['hero_image']['name'], PATHINFO_EXTENSION);
        $heroName = uniqid('hero_') . '.' . $ext;
    
        if (move_uploaded_file($_FILES['hero_image']['tmp_name'], $uploadDir . $heroName)) {
            $hero_image = $uploadPath . $heroName;
        }
    }

 
    
    // THUMBNAIL
    if (isset($_FILES['thumb_nail']) && $_FILES['thumb_nail']['error'] === UPLOAD_ERR_OK) {
    
        $uploadDir  = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/thumbnail/';
        $uploadPath = 'assets/images/thumbnail/';
    
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
    
        $ext = pathinfo($_FILES['thumb_nail']['name'], PATHINFO_EXTENSION);
        $thumbName = uniqid('thumb_') . '.' . $ext;
    
        if (move_uploaded_file($_FILES['thumb_nail']['tmp_name'], $uploadDir . $thumbName)) {
            $thumbnail = $uploadPath . $thumbName;
        }
    }

   
   $faqData = [];

    if (!empty($_POST['faq_question']) && !empty($_POST['faq_answer'])) {
        foreach ($_POST['faq_question'] as $index => $question) {
            $faqData[] = [
                'question' => trim($question),
                'answer'   => trim($_POST['faq_answer'][$index] ?? '')
            ];
        }
    }
    
    $faqJson = !empty($faqData) ? json_encode($faqData, JSON_UNESCAPED_UNICODE) : null;
    
  
// var_dump($faqJson);die;

      $labelData = [];

    if (!empty($_POST['label_h']) && !empty($_POST['content_p'])) {
        foreach ($_POST['label_h'] as $index => $question) {
            $labelData[] = [
                'question' => trim($question),
                'answer'   => trim($_POST['content_p'][$index] ?? '')
            ];
        }
    }
    
    $labelJson = !empty($labelData) ? json_encode($labelData, JSON_UNESCAPED_UNICODE) : null;
    /* ===================================================== */

    if ($action === 'edit_blog' && $method === 'edit_content') {

        // if ($category_id === '' || $blog_title === '') {
        //     echo json_encode([
        //         'type' => 0,
        //         'result' => 'Invalid input'
        //     ]);
        //     exit;
        // }

        $updateQuery = "
           UPDATE blogs_content SET
                category_id      = '$category_id',
                published_date   = '$published_date',
                sub_title        = '$sub_title',
                blog_title       = '$blog_title',
                slug             = '$slug',
                read_minutes     = '$read_minutes',
                content          = '$labelJson',
                seo_title        = '$seo_title',
                meta_description= '$meta_description',
                meta_keywords    = '$meta_keywords',
                faq              = '$faqJson',
                thumbnail        = '$thumbnail',
                hero_image       = '$hero_image'
            WHERE id = '$blog_id'

        ";
        
        if ($con->query($updateQuery)) {
            echo json_encode([
                'type' => 1,
                'result' => 'Content updated successfully'
            ]);
             exit;
        } else {
            echo json_encode([
                'type' => 0,
                'result' => 'Update failed: ' . $con->error
            ]);
             exit;
        }
    }
}

resutGJHIP:
echo json_encode($result);
?>