<?php
// echo "<pre>";
// print_r($_GET);
// echo "</pre>";
$pageTitle = "Edit Category";
/* Get category ID from URL
   Example: /category-edit/edit/5
*/
$categoryID = $subid3;
// var_dump($categoryID);
$sql = "SELECT *  FROM `categories`  WHERE `id` = '$categoryID'";
   $run = mysqli_query($con, $sql);
   if (mysqli_num_rows($run) > 0) {
      $row = $run->fetch_assoc();
   }
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
.back-arrow-btn i {
    background: #ffffff;
    font-size: 16px;
    padding: 2px 3px;
    border-radius: 50px;
    border: 2px solid #6c6e70;
    color: #6c6e70;
    margin-right: 15px;
    width: 24px;
    height: 24px;
}
</style>

<div class="main-content app-content mt-0">
    <div class="side-app">
        <div class="main-container container-fluid mt-5 p-0">

            <!-- PAGE HEADER -->
            <div class="page-header pt-5">
                <h1 class="page-title">
                    <a href="javascript:void(0)" class="back-arrow-btn">
                        <i class="fa fa-chevron-left" onclick="history.go(-1)"></i>
                    </a>
                    <?= $pageTitle ?>
                </h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item active"><?= $pageTitle ?></li>
                </ol>
            </div>

            <!-- CONTENT -->
            <div class="row">
                <div class="col-12">

                    <div class="card shadow-sm">
                        <div class="card-body">

                            <input type="hidden" id="category_id" value="<?= $categoryID ?>">

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Category Name</label>
                                    <input type="text" value ="<?=$row['cat_name']?>"
                                           id="category_name"
                                           class="form-control"
                                           placeholder="Enter category name">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Category Page URL</label>
                                    <div class="input-group">
                                        <!--<span class="input-group-text">/category/</span>-->
                                        <input type="text"
                                               id="category_url"
                                               class="form-control"
                                               value ="<?=$row['cat_url']?>"
                                               placeholder="my-awesome-category">
                                    </div>
                                </div>
                            </div>

                            <!-- ACTIONS -->
                            <div class="mt-4">
                                <button class="btn btn-primary me-2" id="updateCategoryBtn">
                                    Update Category
                                </button>
                                <!--<button class="btn btn-outline-secondary" id="resetBtn">-->
                                <!--    Reset-->
                                <!--</button>-->
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    loadCategory();
});

/* Slug validation */
// $("#category_url").on("input", function () {
//     this.value = this.value
//         .toLowerCase()
//         .replace(/[^a-z0-9-]/g, "");
// });

/* LOAD CATEGORY DATA */
// function loadCategory() {
//     let id = $("#category_id").val();

//     if (!id) return;

//     $.ajax({
//         url: "/ajax/service/createCategory_services.php",
//         type: "POST",
//         dataType: "json",
//         data: {
//             method: "get_category",
//             id: id
//         },
//         success: function (res) {
//             if (res.type === 1) {
//                 $("#category_name").val(res.result.category_name);

//                 let slug = res.result.category_url.replace("/category/", "");
//                 $("#category_url").val(slug);

//                 $("#schema_json").val(res.result.schema_json || "");
//             } else {
//                 alert(res.message);
//             }
//         }
//     });
// }

/* UPDATE CATEGORY */
$("#updateCategoryBtn").on("click", function () {

    let id = $("#category_id").val();
    let name = $("#category_name").val().trim();
    let slug = $("#category_url").val().trim();


    if (!name || !slug) {
        alert("Category name and URL are required");
        return;
    }
    
    $.ajax({
        url: "/ajax/service/createCategory_services.php",
        type: "POST",
        dataType: "json",
        data: {
            method: "update_category",
            id: id,
            cat_name: name,
            cat_url: slug
        },
        success: function (res) {
            if (res.type === 1) {
                Swal.fire({
                    toast: true,
                    position: "top-end",
                    icon: "success",
                    title: "Updated successfully",
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                    didClose: () => {
                        window.location.href = "/create-category/";
                    }
                });
            } else {
                 Swal.fire({
                    toast: true,
                    position: "top-end",
                    icon: "error",
                    title: res.result || "Update failed",
                    showConfirmButton: false,
                    timer: 2000,
                    timerProgressBar: true,
                });
            }
        }
    });
});

/* RESET */
$("#resetBtn").on("click", function () {
    loadCategory();
});
</script>